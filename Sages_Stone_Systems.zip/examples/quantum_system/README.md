
Quantum System – Constraint Kernel

Files:
- quantum_system.py
- test_valid.py
- test_violations.py

Run:
python test_valid.py
python test_violations.py
