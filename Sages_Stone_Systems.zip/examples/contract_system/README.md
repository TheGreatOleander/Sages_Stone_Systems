
Contract System – Non-Physics Constraint Example

This system demonstrates the same pattern as QuantumSystem:
- Declared constraints
- Deterministic evaluation
- Honest failure

Files:
- contract_system.py
- test_valid.py
- test_violations.py
