
class AgentSchema:
    REQUIRED_FIELDS = ["name", "version"]
