
# Agent System

Reference implementation of a Stone-compatible system.

Structure:
- schema.py
- invariants.py
- lifecycle.py
