Observers may be layered with lenses.
