No authority to modify state.
