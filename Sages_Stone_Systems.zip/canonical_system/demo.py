
from system import CanonicalSystemMax

if __name__ == "__main__":
    sys = CanonicalSystemMax()
    result = sys.run()
    print("Demo complete:", result)
