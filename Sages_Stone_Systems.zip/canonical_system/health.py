
def check():
    return {
        "status": "ok",
        "checks": {
            "config": True,
            "state": True,
            "runtime": True,
        }
    }
