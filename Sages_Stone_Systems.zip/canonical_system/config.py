
SYSTEM_NAME = "canonical_system_max"
VERSION = "2.0.0"

LOG_LEVEL = "INFO"
STATE_FILE = "state.json"

REQUIRED_FIELDS = [
    "SYSTEM_NAME",
    "VERSION",
    "LOG_LEVEL",
    "STATE_FILE",
]
