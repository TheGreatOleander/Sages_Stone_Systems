# Cryptography System

Defines and maintains cryptographic posture and allowances.

This system represents cryptographic constraints.
It does not perform encryption.
It does not manage keys.
