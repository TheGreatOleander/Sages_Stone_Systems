Runtime may attach containment zones.
