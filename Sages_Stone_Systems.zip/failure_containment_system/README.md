# Failure Containment System

Defines how failures are isolated and propagated.
