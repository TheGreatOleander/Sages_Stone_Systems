Does not attempt recovery logic.
