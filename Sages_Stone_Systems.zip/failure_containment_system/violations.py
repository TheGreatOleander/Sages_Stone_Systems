class UncontainedFailure(Exception):
    pass
