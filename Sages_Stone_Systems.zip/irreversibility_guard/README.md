Irreversibility Guard
=====================

Defines actions that may never be undone.
Once crossed, the system must acknowledge permanence.
