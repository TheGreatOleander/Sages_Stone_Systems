# Irreversibility Guard

Prevents rollback, erasure, or time-reversal of committed state.
