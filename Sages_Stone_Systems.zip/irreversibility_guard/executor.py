def mark_irreversible(action):
    return {"action_id": action.action_id, "irreversible": True}
