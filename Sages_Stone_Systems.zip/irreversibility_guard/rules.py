def enforce_irreversibility(action):
    return True  # acknowledgment only
