class ReversalAttempt(Exception):
    pass
