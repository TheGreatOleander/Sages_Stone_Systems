# Authority Boundary

Defines who may act and where authority ends.
