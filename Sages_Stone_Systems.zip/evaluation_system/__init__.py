"""
Evaluation System

Canonical, non-executing system defining evaluation posture,
constraints, and validation invariants.

This system performs no computation.
"""
