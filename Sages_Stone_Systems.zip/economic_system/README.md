# economic_system/README.md

## Economic System

The Economic System records and exposes economic facts.

This system:
- Tracks value-related events
- Maintains no opinions or policies
- Performs no optimization or enforcement

Interpretation and governance occur elsewhere.
