# economic_system/__init__.py
from .system import System

__all__ = ["System"]
