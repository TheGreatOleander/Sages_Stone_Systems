# Cosmology System

Defines and maintains the structural model of reality.

This system represents the shape and rules of the world.
It does not simulate events.
It does not perform causation.
