# Cognition System

Defines and maintains cognitive state.

This system represents awareness and interpretation.
It does not reason.
It does not decide.
It does not act.
