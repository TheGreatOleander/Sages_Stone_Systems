"""
Example System

Reference implementation demonstrating canonical system structure.
This system exists for illustration only.
"""
