# Example System

The Example System is a reference implementation used to demonstrate
canonical system structure and expectations.

It exists to:
- show correct system layout
- demonstrate lifecycle and invariant wiring
- provide a safe template for new systems

This system is intentionally minimal and non-authoritative.
