# Death System

Defines and maintains terminal state.

This system represents irreversibility.
It does not cause death.
It does not simulate decay.
