from .system import DeathSystem

__all__ = ["DeathSystem"]
