# Ecology System

Defines and maintains ecological state.

This system represents relationships and balances.
It does not simulate dynamics.
It does not optimize outcomes.
