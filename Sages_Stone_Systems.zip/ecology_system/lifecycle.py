class EcologyLifecycle:
    def start(self) -> None:
        pass

    def stop(self) -> None:
        pass
