from .system import EcologySystem

__all__ = ["EcologySystem"]
