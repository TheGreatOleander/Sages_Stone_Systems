# Climate System

Defines and maintains environmental climate state.

This system represents conditions.
It does not simulate physics.
It does not enact policy or behavior.
