class Violation(Exception):
    """Raised on invariant or boundary breach."""
    pass
