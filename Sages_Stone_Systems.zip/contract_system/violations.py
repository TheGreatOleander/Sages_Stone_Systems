class ContractViolation(Exception):
    pass
