class Violation(Exception):
    """Raised when system invariants are broken."""
    pass
