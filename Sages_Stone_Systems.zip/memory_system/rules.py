class Rules:
    """Invariant rules enforced by the system."""
    pass
