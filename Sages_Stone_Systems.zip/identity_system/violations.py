class IdentityViolation(Exception):
    pass\n