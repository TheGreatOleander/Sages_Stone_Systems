# Execution Context System

Defines what it means for something to be executing.
