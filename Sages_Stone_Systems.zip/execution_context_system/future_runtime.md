Future runtimes must bind execution to a context handle.
