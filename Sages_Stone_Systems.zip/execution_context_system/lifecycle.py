class ExecutionContextLifecycle:
    def start(self) -> None:
        pass

    def stop(self) -> None:
        pass
