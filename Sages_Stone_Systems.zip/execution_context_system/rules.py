class Rules:
    """Invariant rules that must always hold."""
    def check(self, data):
        return True
