from .system import CapabilityBoundarySystem

__all__ = ["CapabilityBoundarySystem"]
