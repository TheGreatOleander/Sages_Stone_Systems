# Capability Boundary System

Defines and enforces which capabilities may be exercised within a given
execution context.

This system constrains capability usage.
It does not grant authority.
It does not execute behavior.
