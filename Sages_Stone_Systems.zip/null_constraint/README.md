# Null Constraint System

This system defines what *cannot exist*.
Anything not explicitly permitted is invalid by default.
